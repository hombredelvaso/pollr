var CONFIG = (function(){
  var branding = {};

  var information = {
    id: 'http://careerdevelopment.aaas.org/course1',
    title: 'Course 1',
    name: 'Avoiding Common Errors in Proposal Writing'
  };

  return {
    information: information
  }
}());